<?php

namespace App\Controllers;

class Tes extends BaseController
{
    public function index(): string
    {
        return view('tes');
    }
}
